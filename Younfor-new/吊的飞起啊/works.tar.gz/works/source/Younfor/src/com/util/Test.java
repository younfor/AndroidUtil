package com.util;

import com.ai.PokerLib;

public class Test {
	/*
	public static void main(String []args)
	{
		String c[]={"8S","8D"," 8S"," 7D"," 2S"};
		PokerLib.init();
		int a=PokerLib.stringToCard("8D");
		int b=PokerLib.stringToCard("8S");
		int d=PokerLib.stringToCard("8S");
		int f=PokerLib.stringToCard("7D");
		int g=PokerLib.stringToCard("2S");
		System.out.println(a+" "+b+" "+d+" "+f+" "+g);
		int res=PokerLib.eval_5cards(a, b,d,f,g  );
		System.out.println(PokerLib.hand_rank(res));
	}*/
}
